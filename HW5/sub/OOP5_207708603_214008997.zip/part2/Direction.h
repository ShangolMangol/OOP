#ifndef PART2_DIRECTION_H
#define PART2_DIRECTION_H

enum Direction
{
    UP = 0,
    DOWN = 1,
    LEFT = 2,
    RIGHT = 3
};

#endif //PART2_DIRECTION_H
