#ifndef PART2_CELLTYPE_H
#define PART2_CELLTYPE_H

enum CellType{
    EMPTY, X, A, B, C, D, E, F, G, H, I, J, K, O, P, Q, R
};

#endif //PART2_CELLTYPE_H
